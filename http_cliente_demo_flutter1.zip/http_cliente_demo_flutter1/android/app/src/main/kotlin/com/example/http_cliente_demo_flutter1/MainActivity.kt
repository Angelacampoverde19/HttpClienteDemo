package com.example.http_cliente_demo_flutter1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
